import Debug from 'debug'
import { SATURN_NETWORK } from '../config.js'

export const debug = Debug(`node-${SATURN_NETWORK}`)
