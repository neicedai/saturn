export const parseVersionNumber = (version) => Number(version.split('_')[0])
